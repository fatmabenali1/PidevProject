/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package PanierP;

import RoadRevel.Services.PanierService;
import RoadRevel.entities.Panier;
import static com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author fatma
 */
public class PanierController implements Initializable {

    @FXML
    private TextField Description;
    @FXML
    private TextField Quantity;
    @FXML
    private TextField Submit;
    @FXML
    private TextField rechercher;
    @FXML
    private ListView<?> tv;
    @FXML
    private TextField id_Panier;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void ajouter(ActionEvent event) {
        PanierService sp = new PanierService();
        int quantite = Integer.parseInt(Quantity.getText());
        sp.ajouter(new Panier(Description.getText(),quantite));
        JOptionPane.showMessageDialog(null, "Personne ajoutée !");
    }

    @FXML
    private void modifier(ActionEvent event) {
        PanierService sp = new PanierService();
        int quantite = Integer.parseInt(Quantity.getText());
        sp.modifier(new Panier( Integer.parseInt(id_Panier.getText()),Description.getText(),quantite));
       JOptionPane.showMessageDialog(null, "Offre "+Integer.parseInt(id_Panier.getText())+" modifié avec succès.");       
                JOptionPane.showMessageDialog(null, "Offre "+Description.getText()+" modifié avec succès.");
    

    }

    @FXML
    private void supprimer(ActionEvent event) {
	PanierService s = new PanierService();
	s.supprimer(new Panier(Panier.getId_Panier()));    
	JOptionPane.showMessageDialog(null, "Offre "+offre.getTitre()+" By "+offre.getNomRecruteur()+" Supprimé.");
    }
    private void afficher (ActionEvent event){

         
    }
}
