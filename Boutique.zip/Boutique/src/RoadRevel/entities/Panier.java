/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RoadRevel.entities;

import java.util.Objects;
import javafx.scene.control.Label;

/**
 *
 * @author fatma
 */
public class Panier {
  int id_Panier;
 String Desciption;
 int Quantity;

    public Panier(int id_Panier, String Desciption, int Quantity) {
        this.id_Panier = id_Panier;        
        this.Desciption = Desciption;
        this.Quantity = Quantity;
    }

    public Panier(int id_Panier) {
        this.id_Panier = id_Panier;
    }

    public Panier(String Desciption, int Quantity) {
        this.Desciption = Desciption;
        this.Quantity = Quantity;
    }

    public Panier(Label id_Panier) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getId_Panier() {
        return id_Panier;
    }

    public String getDesciption() {
        return Desciption;
    }



    public int getQuantity() {
        return Quantity;
    }

    public void setId_Panier(int id_Panier) {
        this.id_Panier = id_Panier;
    }

    public void setDesciption(String Desciption) {
        this.Desciption = Desciption;
    }


    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + this.id_Panier;
        hash = 83 * hash + Objects.hashCode(this.Desciption);
        hash = 83 * hash + this.Quantity;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Panier other = (Panier) obj;
        if (this.id_Panier != other.id_Panier) {
            return false;
        }
        if (this.Quantity != other.Quantity) {
            return false;
        }
        if (!Objects.equals(this.Desciption, other.Desciption)) {
            return false;
        }
          return false;

 
    }
    @Override
    public String toString() {
        return "Panier{" + "id_Panier=" + id_Panier + ", Desciption=" + Desciption + ", Quantity=" + Quantity + '}';
    }
}




