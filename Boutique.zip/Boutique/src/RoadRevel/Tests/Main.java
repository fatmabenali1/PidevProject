/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RoadRevel.Tests;
import RoadRevel.Services.*;
import RoadRevel.entities.Panier;
import java.util.Date;
/**
 *
 * @author fatma
 */
public class Main {
        public static void main(String[] args) {
            PanierService pst = new PanierService();
            pst.ajouter(new Panier(123,"aeze",521));
        }
}
