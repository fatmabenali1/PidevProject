/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RoadRevel.Services;


import RoadRevel.Utils.DataSource;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import RoadRevel.entities.Panier;
/**
 *
 * @author fatma
 */
public class PanierService implements IService<Panier>{
        private final Connection cnx = DataSource.getInstance().getCnx();
   @Override
    public void ajouter(Panier p) {
        String req = "INSERT INTO Panier(Desciption , Quantity) VALUES(?, ? );";
        try {
            //Statement st = cnx.createStatement();
            PreparedStatement pst = cnx.prepareStatement(req);
            pst.setString(1, p.getDesciption());
            pst.setInt(2, p.getQuantity());
            pst.executeUpdate();
            System.out.println("Quantité ajoutée !");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void modifier(Panier p) {
        String req = "UPDATE  Panier SET Desciption=? , Quantity= ?   WHERE id_Panier=?";
        try {
            PreparedStatement pst = cnx.prepareStatement(req);
            pst.setString(1, p.getDesciption());
            pst.setInt(2, p.getQuantity());
            pst.setInt(3, p.getId_Panier());
            pst.executeUpdate();
            System.out.println("Panier modifiée !");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void supprimer(Panier p) {
        String req = "DELETE FROM Panier WHERE id_Panier=?";
        try {
            PreparedStatement pst = cnx.prepareStatement(req);
            pst.setInt(1, p.getId_Panier());
            pst.executeUpdate();
            System.out.println("Panier supprimée !");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public List<Panier> afficher() {
        List<Panier> list = new ArrayList<>();
        
        String req = "SELECT * FROM Panier";
        try {
            PreparedStatement pst = cnx.prepareStatement(req);
            ResultSet result = pst.executeQuery();
            while(result.next()) {
                list.add(new Panier(result.getInt("id_Panier"), result.getString("Desciption"),result.getInt("Quantity")));
            }
            System.out.println("Panier récupérées !");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
        return list;
    }


}



